package com.demo1.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo1.bean.Result;
import com.demo1.bean.User;
import com.demo1.service.LoginService;

@RestController
public class RestControllerClass {

	@Autowired
	LoginService loginService;
	
	@GetMapping("/getAll/Users")
	public List<User> getAllUser() {
		System.out.println("In rest controller get method");
		return loginService.getUsers();
	}
	
	@PostMapping("/checkUser")
	public Result checkUser(@RequestBody User user) throws SQLException {
		System.out.println("In rest controller check method");
		System.out.println("User: "+user.getUserid()+" --> Password: "+user.getPassword());
		//User user = new User();
		//user.setUserid(userid);
		//user.setPassword(Integer.parseInt(password));
		
		boolean res = loginService.checkExists(user);
		Result result = new Result();
		if(res)
			result.setResult("true");
		else
			result.setResult("false");
		
		return result;
		
	}
	
}
