package com.demo1.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.demo1.bean.User;
import com.demo1.service.LoginService;

@Controller
public class ActivityController {
	
	@Autowired
	LoginService loginService;

	@RequestMapping("/login")
	public ModelAndView loginControl() {
		return new ModelAndView("login");
	}
	
	@RequestMapping("/loginControl")
	public ModelAndView welcome(HttpServletRequest req, HttpServletResponse res) throws SQLException {
			
		try {
			HttpSession session = req.getSession();
			String userid = req.getParameter("userid");
			int password = Integer.parseInt(req.getParameter("password"));
			
			User user = new User();
			user.setUserid(userid);
			user.setPassword(password);
		
			ModelAndView mv;
			
			if(loginService.checkExists(user)) {
				mv = new ModelAndView("welcome");
				session.setAttribute("user", userid);
			}else {
				mv=new ModelAndView("login");
				mv.addObject("message", "Invalid UserName/Password");
			}
			return mv;
		}
		catch(SQLException|NumberFormatException e) {
			e.printStackTrace();
			return new ModelAndView("error");
		}
	}
	
	
	@RequestMapping("/getList")
	public ModelAndView getList(HttpServletRequest req, HttpServletResponse res) {
		
		try {
			
			List<User> userList = loginService.getUsers();
			ModelAndView mv=new ModelAndView();
			
			if(userList != null) {
				mv = new ModelAndView("welcome");
				mv.addObject("userList", userList);			
				return mv;
			}
			return new ModelAndView("error");
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ModelAndView("error");
		}
		
		
	}
	
	
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest req, HttpServletResponse res) {
		
			HttpSession session = req.getSession();
			session.invalidate();
			return new ModelAndView("login");
		
	}
}
