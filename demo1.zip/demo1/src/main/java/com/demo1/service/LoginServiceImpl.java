package com.demo1.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo1.bean.User;
import com.demo1.dao.LoginDAO;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginDAO logindao;
	
	@Override
	public boolean checkExists(User user) throws SQLException {
		return logindao.checkUser(user);
	}

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return logindao.getUsers();
	}

}
