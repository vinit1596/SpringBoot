package com.demo1.service;

import java.sql.SQLException;
import java.util.List;

import com.demo1.bean.User;

public interface LoginService {

	boolean checkExists(User user) throws SQLException;

	List<User> getUsers();
	
}
