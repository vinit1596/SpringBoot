package com.demo1.dao;

import java.sql.SQLException;
import java.util.List;

import com.demo1.bean.User;

public interface LoginDAO {

	boolean checkUser(User user) throws SQLException;
	
	List<User> getUsers();
	
}
