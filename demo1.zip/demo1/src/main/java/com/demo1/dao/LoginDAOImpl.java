package com.demo1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.demo1.bean.User;

@Repository
public class LoginDAOImpl extends JdbcDaoSupport implements LoginDAO {

	@Autowired
	DataSource dataSource;
		
	@PostConstruct
	private void initialize(){
		setDataSource(dataSource);
	}

	@Override
	public boolean checkUser(User user) throws SQLException {
		
		Connection con = null;
		PreparedStatement ps = null;
		try{
			String sql = "SELECT * FROM DEMOTABLE WHERE KEY=? AND VALUE=?";
			con = dataSource.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getUserid());
			ps.setInt(2, user.getPassword());
			ResultSet rs = ps.executeQuery();
			boolean res = false;
			
			//Can use JDBC Template Also
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			User us = jdbcTemplate.queryForObject(sql, new Object[] {user.getUserid(), user.getPassword()}, new RowMapper<User>() {
				@Override
				public User mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					User emp = new User();
					emp.setPassword(rs.getInt("value"));
					emp.setUserid(rs.getString("key"));
					return emp;
				}
			});
			
			//System.out.println("JDBC Template data:"+us.getUserid()+"------"+us.getPassword());
			
			if(rs.next()) {
				//System.out.println("Data fetched:"+rs.getString("key")+"----"+rs.getInt("value"));
				res=true;
			}
		
			return res;
			
			
		}
		catch(SQLException e) {
			e.printStackTrace();
			
		}
		
		return false;
	}
	
	
	@Override
	public List<User> getUsers(){
		Connection con = null;
		Statement st = null;
		
		try{
			String sql = "SELECT * FROM DEMOTABLE";
			con = dataSource.getConnection();
			st = con.createStatement();
			List<User> userList = new ArrayList<User>();
			
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String,Object>> userRows = jdbcTemplate.queryForList(sql);
			
			for(Map<String,Object> userRow : userRows){
				User emp = new User();
				emp.setPassword(Integer.parseInt(String.valueOf(userRow.get("value"))));
				emp.setUserid(String.valueOf(userRow.get("key")));
				userList.add(emp);				
			}
			System.out.println("Users fetched:"+userList.size());
			return userList;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
